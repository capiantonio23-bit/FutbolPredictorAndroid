package es.antonio.futbolpredictor

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import java.io.ByteArrayInputStream
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var assetLoader: WebViewAssetLoader

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.databaseEnabled = true
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = false
        webView.settings.javaScriptCanOpenWindowsAutomatically = false
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val uri = request.url
                if (uri.host == "appassets.androidplatform.net") return assetLoader.shouldInterceptRequest(uri)
                if (uri.scheme == "https" && uri.host == "site.api.espn.com" && uri.path?.startsWith("/apis/") == true) {
                    return fetchEspn(uri.toString(), request.method)
                }
                return super.shouldInterceptRequest(view, request)
            }
        }
        setContentView(webView)
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    private fun fetchEspn(address: String, method: String): WebResourceResponse {
        val cors = mapOf(
            "Access-Control-Allow-Origin" to "https://appassets.androidplatform.net",
            "Access-Control-Allow-Methods" to "GET, OPTIONS",
            "Access-Control-Allow-Headers" to "Content-Type, Accept",
            "Vary" to "Origin",
            "Cache-Control" to "no-store"
        )
        if (method.equals("OPTIONS", true)) {
            return WebResourceResponse("application/json", "UTF-8", 204, "No Content", cors, ByteArrayInputStream(ByteArray(0)))
        }
        return try {
            val connection = (URL(address).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 12000
                readTimeout = 15000
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", "FutbolPredictorAndroid/1.0")
            }
            val code = connection.responseCode
            val stream = if (code in 200..399) connection.inputStream else connection.errorStream
            val bytes = stream?.use { it.readBytes() } ?: ByteArray(0)
            val headers = HashMap(cors)
            connection.contentType?.let { headers["Content-Type"] = it }
            connection.disconnect()
            WebResourceResponse("application/json", "UTF-8", code, if (code in 200..399) "OK" else "Upstream error", headers, ByteArrayInputStream(bytes))
        } catch (e: Exception) {
            val payload = "{\"__proxyError\":true,\"message\":\"${(e.message ?: "Network error").replace("\\", "\\\\").replace("\"", "\\\"")}\"}".toByteArray()
            WebResourceResponse("application/json", "UTF-8", 502, "Bad Gateway", cors, ByteArrayInputStream(payload))
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
